def fullname(first_name, last_name):
    full_name = first_name + " " + last_name
    return full_name


def string_alternative(input_string):
    return input_string[::2]


def main():
    first_name = input("Please enter your first name: ")
    last_name = input("Please enter your last name: ")

    full_name = fullname(first_name, last_name)
    alternative_chars = string_alternative(full_name)

    print("your full name is:", full_name)
    print("Every other character in full name:", alternative_chars)


if __name__ == "__main__":
    main()
